#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

//--------------
long long fib(int n) {
    long long i, j;
    if (n < 2)
        return n;
    else if (n < 20) return fib(n-1)+fib(n-2);
    else {
       #pragma omp task shared(i)
       i = fib(n-1);

       #pragma omp task shared(j)
       j = fib(n-2);

       #pragma omp taskwait
       return i + j;
    }
}

//--------------------------------
int main(int argc, char* argv[]) {
    int thread_count, n;

    thread_count = 4;
    n = 15;

    if (argc > 2) {
        thread_count = atoi(argv[1]);
        n = atoi(argv[2]);
    }

    omp_set_num_threads(thread_count);

    // time
    double t0 = omp_get_wtime();

    #pragma omp parallel shared(n)
    {
        #pragma omp single // master
        {
        for (int i = 1; i <= n; i++)
            printf("%lld ", fib(i));
        printf("\n");
        }
    }

    double t1 = omp_get_wtime();
    printf("time = %.3f sec\n", t1 - t0);
}
