/*
Try to compute n Fibonacci numbers using OpenMP.  
Show what happens if we try to parallelize a loop
with dependences among the iterations.  
The program has a serious bug.
*/
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int main(int argc, char *argv[])
{
    int thread_count, n, i;
    long long *fibo;

    thread_count = 4;
    n = 15;

    if (argc > 2) {
        thread_count = atoi(argv[1]);
        n = atoi(argv[2]);
    }

    fibo = malloc(n * sizeof(long long));
    
    fibo[0] = fibo[1] = 1;

    #pragma omp parallel for num_threads(thread_count)
    for (i = 2; i < n; i++)
        fibo[i] = fibo[i - 1] + fibo[i - 2];

    printf("The first %d Fibonacci numbers:\n", n);
    for (i = 0; i < n; i++)
        printf("%lld ", fibo[i]);
    printf("\n");

    free(fibo);
    return 0;
}
