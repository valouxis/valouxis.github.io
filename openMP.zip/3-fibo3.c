#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <omp.h>

//--------------------------
long long fib(int n, long long * arr) {
    long long i, j;

    if (n < 2) {
        return n;
    }
    else if (arr[n]) {
        return arr[n];
    }
    else {
       #pragma omp task shared(i)
       i = fib(n-1, arr);

       #pragma omp task shared(j)
       j = fib(n-2, arr);

       #pragma omp taskwait
       arr[n] = i+j;
       return i + j;
    }
}

//--------------------------------
int main(int argc, char* argv[]) {
    struct timeval tv0, tv1;
    int thread_count, n;
    long long* arr;

    thread_count = 4;
    n = 15;

    if (argc > 2) {
        thread_count = atoi(argv[1]);
        n = atoi(argv[2]);
    }

    omp_set_num_threads(thread_count);

    arr = malloc((n + 1) * sizeof(long long));

    // time
    gettimeofday(&tv0, NULL);

    #pragma omp parallel shared(n, arr)
    {
        #pragma omp single
        {
        for (int i = 1; i <= n; i++) {
            for (int k = 0; k <= i; k++) 
                arr[k] = 0;
            arr[1] = 1;
            
            // printf("%lld ", fib(i, arr));
        }
        // printf("\n");
        }
    }
    gettimeofday(&tv1, NULL);
    printf("time = %.3f sec\n", (tv1.tv_sec - tv0.tv_sec +  
            ((double)tv1.tv_usec - tv0.tv_usec) / 1e6));
}
