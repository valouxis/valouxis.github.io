/*
A parallel hello world program that uses OpenMP

export OMP_NUM_THREADS=4 (win: set OMP_NUM_THREADS=4)
unset OMP_NUM_THREADS    (win: set OMP_NUM_THREADS=) 

Compile:  
    gcc -g -Wall -fopenmp -o 1-hello 1-hello.c
    or
    gcc -fopenmp -o <filename> <file>.c
    
for mac use gcc-9
*/
#include <stdio.h>
#include <stdlib.h>
#include <omp.h>   

// Thread function
void hello(void);

//--------------------------------
int main(int argc, char* argv[]) {
    int thread_count = 4;
 
    if (argc > 1)
        thread_count = atoi(argv[1]); 

    // omp_set_num_threads(7);

    #pragma omp parallel num_threads(thread_count) 
    {
    hello();
    }

    printf("done\n");
    return 0; 
}

//----------------
void hello(void) {
    int my_rank = omp_get_thread_num();
    int thread_count = omp_get_num_threads();

    printf("--Hello--");
    printf("from thread %d of %d\n", my_rank, thread_count);
}
