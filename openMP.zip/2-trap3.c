/*
Estimate definite integral (or area under curve)
using trapezoidal rule
using 
    prallel for, reduction()
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>

double f(double x);    /* Function we're integrating */
double trap(double a, double b, int n, int thread_count);

//--------------------------------
int main(int argc, char* argv[]) {
    double  global_result = 0.0;  /* Store result in global_result */
    double  a, b;                 /* Left and right endpoints      */
    int     n;                    /* Total number of trapezoids    */
    int     thread_count;

    thread_count = 4;
    a = 1;
    b = 5;
    n = 1e8;//100000000;

    if (argc > 1) {
        thread_count = atoi(argv[1]);
    }
    if (argc > 4) {
        thread_count = atoi(argv[1]);
        a = atof(argv[2]);
        b = atof(argv[3]);
        n = atoi(argv[4]);
    }

    // time
    double t0 = omp_get_wtime();
    global_result = trap(a, b, n, thread_count);
    double t1 = omp_get_wtime();

    printf("time = %.3f sec\n", t1 - t0);

    printf("With %d threads and n = %d trapezoids\n", thread_count, n);
    printf("of the integral from %.2f to %.2f = %.6f\n", a, b, global_result);
    return 0;
}

//------------------
double f(double x) {
    return x * x;
}

//--------------------------------------------------------
double trap(double a, double b, int n, int thread_count) {
    double  h, approx;
    int  i;

    h = (b-a)/n; 
    approx = (f(a) + f(b))/2.0; 
    
    #pragma omp parallel for num_threads(thread_count) \
        reduction(+: approx)
    for (i = 1; i <= n-1; i++)
        approx += f(a + i * h);
    
    approx = h * approx; 

    return approx;
}
