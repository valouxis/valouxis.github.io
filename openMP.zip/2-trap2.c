/*
Estimate definite integral (or area under curve)
using trapezoidal rule
using
    #pragma omp parallel reduction()
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>

double f(double x);    // Function we're integrating
double trap(double a, double b, int n);

//--------------------------------
int main(int argc, char* argv[]) {
    double  global_result = 0.0;  // Store result in global_result 
    double  a, b;                 // Left and right endpoints      
    int     n;                    // Total number of trapezoids    
    int     thread_count;

    thread_count = 4;
    a = 1;
    b = 5;
    n = 10000000;

    if (argc > 1) {
        thread_count = atoi(argv[1]);
    }
    if (argc > 4) {
        thread_count = atoi(argv[1]);
        a = atof(argv[2]);
        b = atof(argv[3]);
        n = atoi(argv[4]);
    }

    global_result = 0.0;
    // use this
    // #pragma omp parallel num_threads(thread_count) 
    // {
    //     double my_result = trap(a, b, n);
    //     #pragma omp critical
    //     global_result += my_result;
    // }
    // or better use this
    #pragma omp parallel num_threads(thread_count) \
            reduction(+: global_result)
    global_result += trap(a, b, n);

    printf("With %d threads and n = %d trapezoids\n", thread_count, n);
    printf("of the integral from %.2f to %.2f = %.6f\n",
            a, b, global_result);
    return 0;
}

//------------------
double f(double x) {
    return x * x;
}

//--------------------------------------
double trap(double a, double b, int n) {
    double  h, x, my_result;
    double  local_a, local_b;
    int  i, local_n;
    
    int my_rank = omp_get_thread_num();
    int thread_count = omp_get_num_threads();

    h = (b-a) / n; 
    local_n = n / thread_count;  
    
    local_a = a + my_rank * local_n*h; 
    local_b = local_a + local_n * h; 
    
    my_result = (f(local_a) + f(local_b))/2.0; 
    for (i = 1; i <= local_n-1; i++) {
        x = local_a + i * h;
        my_result += f(x);
    }
    my_result = my_result * h; 

    return my_result; 
}
