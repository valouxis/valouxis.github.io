/*
Compute a sum in which each term is the value 
of a function applied to a nonnegative integer i 
and evaluation of the function 
requires work proportional to i.
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>

double f(long i);

//------------------------------
int main(int argc, char *argv[])
{
    double sum;         // Store result in sum
    long n;             // Number of terms
    int thread_count;

    thread_count = 4;
    n = 10000;
    
    if (argc > 2) {
        thread_count = atoi(argv[1]);
        n = atol(argv[2]);
    }

    double t0 = omp_get_wtime();
    sum = 0.0;
    #pragma omp parallel for num_threads(thread_count) \
            reduction(+ : sum) schedule(dynamic)
            // schedule static, dynamic, guided, auto, runtime
    for (long i = 0; i < n; i++) {
        sum += f(i);
    }
    double t1 = omp_get_wtime();

    printf("Result = %.14lf\n", sum);
    printf("time   = %.3lf sec\n", t1 - t0);

    return 0;
}

//--------------
double f(long i)
{
    long j;
    long start = i * (i + 1) / 2;
    long finish = start + i;
    double return_val = 0.0;

    for (j = start; j <= finish; j++) {
        return_val += sin(j);
    }
    return return_val;
}
